# 02 · Pages

Four routes. The hi-fi reference stacks all four in one file (separated by dark "PAGE 0X" reference bars — those bars are NOT part of the site). Below is what each real page contains.

Shared across all pages: sticky **nav** (brand + Home/Projects/About/Contact + "Get in touch" CTA) and **footer** (© line + tagline).

---

## Page 01 — Home (`/`)
The 20-second pitch.

1. **Hero** — mono kicker with pulsing accent dot ("Data & Software Engineer · UK"), big headline *"Clear systems, clean code, a little rhythm."* (accent on "clean code"), one-paragraph lede, two buttons (View work → /projects, Download CV → PDF). A small stat row: `9+ shipped projects`, `2 eng bootcamps`, and a `session musician` stat rendered with the animated **waveform**.
2. **Core stack strip** — mono "CORE STACK" label + a row of hover-able tech chips.
3. **Selected work** — `// featured` index + h2, "All projects" ghost button, then a **3-card grid** of the top 3 projects (STS Analyser, Course Hosting, Cloud Audio Analysis).
4. **Music strip** — full-width white band: ♪ icon, "Off the clock, I make music" + one line, Bandcamp & YouTube links. This is the *small* music section Jeremy asked for.

## Page 02 — Projects (`/projects`)
1. Section header: `// projects`, h2 "Everything I've built", one-line intro.
2. **Filter pills:** All / Data / Web / Cloud (functional — filter the grid by category).
3. **Full grid** of all 9 projects (same card component as home). Each card: thumbnail with a category tag overlay, title, 1–2 sentence description, mono tech tags, and links (GitHub / Demo / Docs / Video as applicable).

> Categories per project are in `03-content.md`. A project can match multiple (e.g. "Data · Web") — filter by "contains".

## Page 03 — About (`/about`)
Two-column (sticky portrait left, narrative right; stacks on mobile).
- **Left:** avatar image in a rounded card + a small status badge ("Open to opportunities & freelance").
- **Right:** `// about` index, h2 "Engineer by training, musician by instinct.", two bio paragraphs (verbatim in `03-content.md`), then a **2×2 skill groups** block (Code / Cloud & DevOps / Data / Testing), then an "Off the clock" interests line.

## Page 04 — Contact (`/contact`)
- A single dark **panel** (ink background, rounded `--r-xl`) centered: `// contact`, h2 "Let's build something.", one line, a large mono **email button** (`mailto:`), and a row of social links (GitHub / Bandcamp / YouTube). A faint decorative **waveform band** sits along the bottom of the panel.

---

### Notes
- The nav CTA and hero "Download CV" should point to a real CV PDF — ask Jeremy for the file, drop it in `/public`, link it. Until then, link to `#` and leave a `TODO`.
- Keep the music thread consistent: waveform on home hero + contact panel, music strip on home, "musician" framing in the About headline. Don't over-do it elsewhere.
