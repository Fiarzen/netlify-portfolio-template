# Jeremy Lam — Portfolio Redesign · Claude Code Handoff

This folder is a complete build brief for a clean redesign of **jeremylam.netlify.app**.
Hand it to Claude Code and point it at this README.

## What's here

| File | Purpose |
|---|---|
| `README.md` | You are here — start here |
| `CLAUDE.md` | Drop-in project instructions for Claude Code (rules + conventions) |
| `Direction C — Hi-Fi Reference.html` | **The visual + code target.** Open in a browser. Lift markup, tokens, spacing and interactions from here. |
| `01-design-system.md` | Color, type, spacing, motion tokens |
| `02-pages.md` | Page-by-page build spec (Home / Projects / About / Contact) |
| `03-content.md` | Real content inventory — projects, skills, bio, links |
| `04-build-plan.md` | Recommended stack + step-by-step milestones |
| `assets/images/` | Real project screenshots + avatar, ready to use |

## TL;DR for the build

- **Direction:** "Minimal Grid" — clean, professional, fast, recruiter-friendly, with a subtle musician identity woven in (waveform motifs, a small music strip).
- **Structure:** multi-page — Home / Projects / About / Contact.
- **Recommended stack:** **Astro** + vanilla CSS (design tokens), Astro Content Collections for projects. See `04-build-plan.md` for the why and the alternative.
- **Deploy:** Netlify (same as today).
- **Motion:** subtle only — hover lifts, accent underlines, one animated waveform. No heavy libraries.

## The one rule

Treat `Direction C — Hi-Fi Reference.html` as the source of truth for *look and feel*. It is a static, single-file mock of all four pages stacked together (with dark "reference chrome" bars marking each page — those are **not** part of the real site). Everything else in these docs explains how to turn it into a real multi-page Astro site without losing the design.
