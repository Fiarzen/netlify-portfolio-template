# 01 · Design System

All values are taken directly from `Direction C — Hi-Fi Reference.html`. Copy the `:root` block from there as your starting point.

## Colors (OKLCH)

```css
:root{
  /* surfaces */
  --paper:        oklch(0.985 0.004 90);   /* page background, warm off-white */
  --surface:      #ffffff;                 /* cards, nav */
  --surface-2:    oklch(0.975 0.006 80);   /* subtle fills, thumbs */

  /* text */
  --ink:          oklch(0.27 0.012 60);    /* headings, primary text */
  --ink-2:        oklch(0.52 0.012 60);    /* body / secondary */
  --ink-3:        oklch(0.66 0.012 60);    /* muted labels, footer */

  /* lines */
  --border:       oklch(0.92 0.006 75);
  --border-2:     oklch(0.88 0.008 70);

  /* accent — warm coral (the musician warmth) */
  --accent:       oklch(0.64 0.155 38);
  --accent-press: oklch(0.57 0.155 38);    /* hover/active */
  --accent-soft:  oklch(0.64 0.155 38 / 0.12);
  --accent-ring:  oklch(0.64 0.155 38 / 0.32);
}
```

The accent is deliberately the only saturated color. Use it for: primary buttons, links, the brand mark, active-nav underline, the `//` section indices, list bullets, and waveform motifs. Everything else is warm neutral.

> Alternate accents explored in the wireframe (swap the hue if Jeremy wants): violet `oklch(0.62 0.15 280)`, teal `oklch(0.6 0.13 200)`, green `oklch(0.64 0.15 145)`. Keep chroma/lightness, change hue only.

## Typography

| Role | Font | Notes |
|---|---|---|
| Display / headings | **Space Grotesk** 600 | tight tracking `-0.025em`, line-height ~1.05 |
| Body | **IBM Plex Sans** 400/500/600 | base 17px, line-height 1.6 |
| Mono / tags / labels | **IBM Plex Mono** 400/500 | tech tags, kickers, `// section` labels, stats |

Type scale (clamp for fluid):
- Hero h1: `clamp(44px, 7vw, 86px)`
- Section h2: `clamp(30px, 4vw, 42px)`
- Card h3: 19px · Body lede: 20px · Body: 17px · Small/mono: 12–14px

## Spacing, radius, shadow

```css
--r-sm:8px; --r-md:14px; --r-lg:20px; --r-xl:28px;
--maxw:1120px;                 /* content container */
--shadow-sm:0 1px 2px rgba(40,30,20,.04), 0 1px 3px rgba(40,30,20,.06);
--shadow-md:0 6px 16px -6px rgba(40,30,20,.12), 0 2px 6px rgba(40,30,20,.05);
--shadow-lg:0 18px 40px -16px rgba(40,30,20,.22);
```
Container: `max-width:1120px; padding:0 32px`. Section vertical rhythm ~64–90px.

## Components
- **Buttons:** `.btn-primary` (accent fill, lifts on hover) and `.btn-ghost` (white, bordered). Arrow `↗` nudges on hover.
- **Chips:** mono text, white, 1px border; on hover border→accent, text→accent, lift 2px.
- **Cards:** white, `--r-lg`, `--shadow-sm` → lifts to `--shadow-lg` on hover; image scales 1.04 inside an `overflow:hidden` thumb.
- **Nav:** sticky, blurred translucent paper bg, active link gets an accent underline (driven by scroll-spy on the home page; route-based on inner pages).
- **Waveform motif:** flex row of thin accent bars. Animated (subtle bob) in the hero; static decorative band behind the contact panel. This is the music thread — keep it small and tasteful.

## Motion
- Transitions 0.15–0.2s on transform/background/border/shadow.
- Hover lifts: 2px (chips/buttons), 5px (cards).
- Hero waveform bob + accent pulse dot on the kicker.
- Nav scroll-spy via `IntersectionObserver`.
- Wrap all non-essential motion in `@media (prefers-reduced-motion: no-preference)`.
