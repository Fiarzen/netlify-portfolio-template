# 03 · Content Inventory

Use this content verbatim. Images are in `assets/images/`.

## Identity
- **Name:** Jeremy Lam
- **Role:** Data & Software Engineer (also: session musician & music educator)
- **Location:** UK
- **Email:** jeremy.fiarzen.lam@gmail.com
- **GitHub:** https://github.com/Fiarzen
- **Bandcamp:** https://jezmusic.bandcamp.com
- **YouTube:** https://www.youtube.com/@JeremyLam0
- **Current site:** https://jeremylam.netlify.app

## Hero copy (suggested — refine with Jeremy)
- Kicker: `Data & Software Engineer · UK`
- Headline: **Clear systems, clean code, a little rhythm.**
- Lede: "I build data pipelines and full-stack apps with Python, AWS and Terraform — and write music when the compiler's happy. Bootcamp-trained, project-obsessed, always shipping."
- Stats: `9+ shipped projects` · `2 eng bootcamps` · `session musician`

## About (verbatim, lightly edited from current site)
> After an intensive 13-week Data Engineering bootcamp with Northcoders and a 12-week Software Development bootcamp with TechNative, I now focus on widening my toolkit — picking up new frameworks while deepening the ones I use daily.
>
> I care about systems that are clean, well-tested and easy to reason about. Most of my projects pair real infrastructure (Terraform, AWS, GCP) with a thoughtful front end. Outside of code I play guitar and write music, with professional experience as a session musician and music educator.

**Off the clock:** Guitar & songwriting · cooking plant-based recipes · weightlifting · videogames with friends.

## Skills (grouped — used on Home strip + About)
- **Code:** Python, Java, JavaScript (Node, React)
- **Cloud:** AWS, Google Cloud Platform
- **DevOps:** Terraform, CI/CD (GitHub Actions)
- **Data:** SQL, Database Modelling, Normalisation, Warehouse Design
- **Design patterns:** Star Schema, Data Lake, Lakehouse, Mesh
- **Testing:** TDD, Pytest, Jest, Vitest

## Projects (9)
Format below maps to a content-collection entry. `featured: true` = show on home (top 3). `categories` drive the Projects filter.

| # | Title | Categories | Tech tags | Image | Links | Featured |
|---|---|---|---|---|---|---|
| 1 | STS 2 Run Analyser | Data, Web | Python, FastAPI, Railway | sts-analyser.png | GitHub: https://github.com/Fiarzen/sts-stats-tracker · Demo: https://sts-stats-tracker-production.up.railway.app | ✅ |
| 2 | Course Hosting Platform | Web, Cloud | Spring Boot, React, AWS, Terraform | course-hosting.png | GitHub: https://github.com/Fiarzen/course-hosting-backend · Demo: https://mind-leaf.netlify.app | ✅ |
| 3 | Cloud Audio Analysis | Cloud, Data | Python, GCP, Node, Terraform | audio-analysis-4.png | GitHub: https://github.com/Fiarzen/audio-analysis · Demo: https://audio-analysis-web-n7afc3734q-ew.a.run.app | ✅ |
| 4 | ETL Sales Pipeline | Data | AWS, Python, Pandas, Tableau, Terraform | pic01.jpg | Video: https://www.youtube.com/watch?v=Wdl2NvBZbqs · GitHub: https://github.com/Fiarzen/de-totes-sales-data | |
| 5 | Guardian API Streaming | Data | AWS Lambda, Python, Terraform | pic02.jpg | GitHub: https://github.com/Fiarzen/Streaming-data-project | |
| 6 | Groove Garden API | Web | Node, Express, PostgreSQL, JWT, Swagger | groove-garden-image.png | GitHub: https://github.com/Fiarzen/groove-garden-backend-api · Docs: https://groove-garden-backend-api-production.up.railway.app/docs | |
| 7 | Stock Market Tracker | Web | JavaScript, Alpha Vantage, Netlify | pic04.jpg | Demo: https://fiarzenstocktracker.netlify.app · GitHub: https://github.com/Fiarzen/stock-tracker | |
| 8 | Sun-time Calculator | Web | JavaScript, API | pic05.png | Demo: https://fiarzen.github.io/sun-times · GitHub: https://github.com/Fiarzen/sun-times | |
| 9 | Carbon Footprint Calculator | Data | Python, Streamlit | pic03.jpg | GitHub: https://github.com/Fiarzen/Carbon-footprint-calculator · Streamlit: https://carbontracker-lbsyapcj8pg9fenqjcvun2.streamlit.app | |

### Project descriptions (verbatim)
1. **STS 2 Run Analyser** — FastAPI backend with a vanilla JS dashboard analysing roguelike run data — card pick rates, relic win rates, encounter difficulty, zip upload & filtering by character/ascension.
2. **Course Hosting Platform** — Spring Boot + React full-stack app: RBAC, lesson tracking, Spring Security, S3 storage and Terraform-provisioned RDS & EC2.
3. **Cloud Audio Analysis** — Audio analysis web app: Python processing, Node/Express backend, vanilla JS frontend, Google Cloud services and Terraform infra.
4. **ETL Sales Pipeline** — A complete data pipeline: Terraform infrastructure on AWS, Python + Pandas ETL and Tableau for business insights.
5. **Guardian API Streaming** — Data streaming project using the Guardian API for content publishing, built with AWS services and Python for AWS Lambda deployment.
6. **Groove Garden API** — Node/Express REST API on Railway with a Postgres DB, Swagger/OpenAPI docs and JWT auth for secure playlist management.
7. **Stock Market Tracker** — A clean interface for retrieving stock data via the Alpha Vantage API, built in JavaScript and deployed to Netlify.
8. **Sun-time Calculator** — Calculates time until sunrise or sunset from coordinates using a sunrise/sunset API. Lightweight vanilla JavaScript.
9. **Carbon Footprint Calculator** — A web app for calculating carbon footprints from everyday activities, built with Python and Streamlit.

> **Ask Jeremy for:** a CV/résumé PDF, and confirmation on whether the placeholder demo links are all still live. Some project thumbnails (pic01–05) are stock images from the old template — replace with real screenshots where possible.
