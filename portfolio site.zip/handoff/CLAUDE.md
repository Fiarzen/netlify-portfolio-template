# CLAUDE.md — Jeremy Lam Portfolio

You are building a clean redesign of a personal portfolio site for **Jeremy Lam**, a Data & Software Engineer who is also a session musician. Audience: recruiters/hiring managers, potential freelance clients, and engineering peers.

## Design intent
- **Professional first, playful second.** Clean, fast, scannable in ~20 seconds. Personality comes from a subtle musician identity (waveform motifs, a small music section, warm coral accent), never from clutter or gimmicks.
- Match the look of `Direction C — Hi-Fi Reference.html` closely. When in doubt, open that file and copy its values.

## Hard rules
- **Tokens only.** All color/spacing/type comes from the CSS custom properties in `01-design-system.md`. Never hardcode a hex that isn't a token.
- **Fonts:** Space Grotesk (display/headings), IBM Plex Sans (body), IBM Plex Mono (tags, labels, code-y bits). Load via Google Fonts or self-host with `@fontsource`.
- **Motion is subtle.** Hover lifts (~2-5px translate), 0.15–0.2s transitions, one animated waveform, an `IntersectionObserver` scroll-spy on the nav. Respect `prefers-reduced-motion`. No GSAP/Framer/AOS.
- **Accessibility:** semantic HTML, real `<nav>`/`<main>`/`<footer>`, alt text on every image, visible focus states, AA contrast, hit targets ≥ 44px.
- **Performance:** static output, lazy-load images, no client JS framework. Lighthouse 95+ across the board is the target.
- **Responsive:** 3-col project grid → 2-col ≤900px → 1-col ≤600px. Test at 375 / 768 / 1280.

## Content
- Real content lives in `03-content.md`. Use it verbatim — do not invent projects, stats, or copy. Project images are in `assets/images/`.
- External links (GitHub/demos) are listed per project in `03-content.md`. Wire them up; open external links in a new tab with `rel="noopener noreferrer"`.

## Do NOT
- Do not add a blog yet — stub the route/nav only if asked; it's deferred.
- Do not add filler sections, dummy testimonials, or stat-padding.
- Do not introduce new accent colors or fonts beyond the tokens.
- Do not keep anything from the old HTML5 UP template (markup, CSS, jQuery) — this is a clean rebuild.

## Definition of done
- Four working pages (Home, Projects, About, Contact) matching the reference.
- Projects driven by a content collection / data file (see `04-build-plan.md`), filterable by category on the Projects page.
- Deploys cleanly to Netlify. README in repo explains local dev + deploy.
