# 04 · Build Plan

## Recommended stack: Astro + vanilla CSS

**Why Astro:**
- Multi-page, mostly-static content site — Astro's sweet spot. Ships **zero JS by default**, so Lighthouse stays high.
- **Content Collections** model the 9 projects as type-safe data — the Projects page and Home "featured" list both render from one source.
- File-based routing gives clean `/`, `/projects`, `/about`, `/contact` with shared layout components.
- One-click **Netlify** deploy (Jeremy already uses Netlify).
- Easy to add the few interactions we need (filter, scroll-spy, waveform) as tiny inline scripts or a sprinkle of Astro islands — no framework required.

**CSS:** plain CSS with the design tokens from `01-design-system.md` in a single `global.css`. (Tailwind is fine if Claude Code prefers it — but map the tokens to the theme; don't lose them.)

**Fonts:** `@fontsource/space-grotesk`, `@fontsource/ibm-plex-sans`, `@fontsource/ibm-plex-mono` (self-hosted, no layout shift), or Google Fonts `<link>` as in the reference.

> Alternative if Astro isn't wanted: plain **Vite + multi-page HTML** (4 html files sharing a CSS file). Simpler, but you re-implement project rendering by hand. Avoid Next.js here — it's overkill for a static portfolio.

## Suggested structure
```
src/
  layouts/  BaseLayout.astro        # <head>, fonts, global.css, nav, footer
  components/
    Nav.astro  Footer.astro  Button.astro
    ProjectCard.astro  SkillChips.astro
    Waveform.astro  MusicStrip.astro
  content/
    projects/                       # one .md/.mdx or a projects.json
    config.ts                       # zod schema: title, categories[], tags[], image, links{}, featured, order, description
  pages/
    index.astro  projects.astro  about.astro  contact.astro
  styles/global.css                 # :root tokens + base + components
public/
  images/                           # project screenshots (from handoff/assets/images)
  cv.pdf                            # TODO: get from Jeremy
```

## Project schema (Content Collection)
```ts
// src/content/config.ts
const projects = defineCollection({
  schema: z.object({
    title: z.string(),
    description: z.string(),
    categories: z.array(z.enum(['Data','Web','Cloud'])),
    tags: z.array(z.string()),
    image: z.string(),                 // /images/...
    links: z.object({                  // any subset
      github: z.string().url().optional(),
      demo:   z.string().url().optional(),
      docs:   z.string().url().optional(),
      video:  z.string().url().optional(),
    }),
    featured: z.boolean().default(false),
    order: z.number().default(99),
  })
});
```
Populate from the table in `03-content.md`.

## Milestones
1. **Scaffold** — `npm create astro@latest`, add fonts, drop in `global.css` with tokens, build `BaseLayout` + `Nav` + `Footer`. Match nav styling/scroll behaviour to the reference.
2. **Content layer** — define the projects collection + schema, enter all 9 projects, copy images into `public/images/`.
3. **Home** — hero (+ animated waveform + pulse dot), stack chips, featured 3 via collection filter, music strip.
4. **Projects** — full grid + working category filter (vanilla JS on the rendered list, or a tiny island).
5. **About** — two-col layout, skill groups, interests, status badge.
6. **Contact** — dark panel, mailto button, socials, decorative waveform.
7. **Polish** — responsive passes (375/768/1280), `prefers-reduced-motion`, focus states, alt text, meta tags + OpenGraph, favicon.
8. **Deploy** — Netlify (`@astrojs/netlify` or static adapter), set up CI from the repo. Write a repo README (dev + deploy).

## Acceptance checklist
- [ ] 4 pages match the hi-fi reference look & feel
- [ ] Projects render from the collection; filter works; all links open correctly (`target="_blank" rel="noopener noreferrer"`)
- [ ] Fully responsive at 375 / 768 / 1280
- [ ] Lighthouse ≥ 95 (Perf / A11y / Best Practices / SEO)
- [ ] No leftover code from the old HTML5 UP template
- [ ] Deploys to Netlify; repo README written
- [ ] `prefers-reduced-motion` respected; visible focus states; AA contrast
